package eurostar;

public class PassengerQueue {
    
    private Passenger[] queueArray = new Passenger[30];
    //front position of queue
    private int first = -1;
    //rear position of queue
    private int last = -1;
    //Maximum passanger in queue
    private int maxStayInQueue = 0 ;
    //Queue size
    private int maxLength = 30 ;
    /**
     * Enqueue elements to rear
     */
    public void add(Passenger next){
        if(isFull()){
            System.out.println("Queue is full, Passenger cannot be added");
        }
        else{
            last = (last + 1) % queueArray.length;
            queueArray[last] = next;
            maxStayInQueue++;
           
            
            if(first == -1){
                first = last;
            }
        }
    }
    /**
     * Dequeue element from Front
     */
    public Passenger remove(){
        
        Passenger dequeuedPassenger = null;
        if(isEmpty()){
            System.out.println("Queue is empty, Element cannot be retrieved");
            
        }
        else{
            dequeuedPassenger = queueArray[first];
            queueArray[first] = null;
            first = (first + 1) % queueArray.length;
            
            maxStayInQueue--;
            
        }
        return dequeuedPassenger;
    }
    /**
     * Check if queue is full
     */
    public boolean isFull() {
        return (maxStayInQueue == queueArray.length);
    }
    /**
     * Check if Queue is empty
     */
    public boolean isEmpty() {
        return (maxStayInQueue == 0);
    }
    /*
    *Display Queue
    */
    public void display(){
        
        int f = first, l = last;
        if(isEmpty()){
            System.out.println("Queue is empty");
        }
        else{
        System.out.println("Passenger Queue");
        System.out.println("-------------------------------------------------");
        
        
        if(f <= l){
            while(f <= l){
                queueArray[f].display();
                f++;
            }
        }
        else{
            while(f <= maxLength - 1){
                queueArray[f].display();
                f++;
            }
            f = 0;
            while(f <= l){
                queueArray[f].display();
                f++;
            }
        }
        }
    }
    
    public void addSecondsToQueue(int seconds){
        
        if(first == -1){
            System.out.println("Queue is empty");
        }
        else{
        
        int i = first;
        
        if(first <= last){
            while(i <= last){
                int oldSeconds = queueArray[i].getSeconds();
                queueArray[i++].setSecondsInQueue(oldSeconds + seconds);
            }
        }
        else{
            while(i <= maxLength - 1)
            {
                int oldSeconds = queueArray[i].getSeconds();
                queueArray[i++].setSecondsInQueue(seconds);
            }
            i = 0;
            while(i <= last)
            {
                int oldSeconds = queueArray[i].getSeconds();
                queueArray[i++].setSecondsInQueue(seconds);
            }
                
            }
        }
    }
    
    public String getQueueString(){
       
       StringBuilder data = new StringBuilder();
       
       int i = first;
       
       if(first <= last){
           while(i <= last){
               data.append(queueArray[i].getName()+" "+queueArray[i].getSeconds()+"\n");
               i++;
              }
       }else{
           
           while(i <= maxLength - 1){
               data.append(queueArray[i].getName()+" "+queueArray[i].getSeconds()+"\n");
               i++;
           }
           i = 0;
           while(i <= last){
               data.append(queueArray[i].getName()+" "+queueArray[i].getSeconds()+"\n");
               i++;
           }
       }
       
       return data.toString();
   }
    /*
    * return Queue length
    */
    public int getLength(){return maxLength;}
    /*
    * return maximum number in queue
    */
    public int getMaxStay(){return maxStayInQueue;}
    
}
