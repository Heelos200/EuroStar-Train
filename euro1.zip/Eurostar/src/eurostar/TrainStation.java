package eurostar;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class TrainStation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //trainQueue
        PassengerQueue trainQueue = new PassengerQueue();
        //name of file to that store data of trainQueue
        String fileName = "trainQueueDate.txt";
        // stored data file object
        File queueData = new File(fileName);
        //dice object
        Random diceRoller = new Random();
        // object for passenger.dat file
        File passengerFile = new File("passengers.dat");
        //defined waiting room
        ArrayList<Passenger> waitingRoom = new ArrayList<Passenger>();
        //report list 
        ArrayList<Passenger> reportList = new ArrayList<Passenger>();
        //object for report.dat file
        File reportFile = new File("report.dat");
        
             
        while(true){
            // Display Menu
            System.out.print("\'A\' Add a passenger to the trainQueue\n\'V\' View the trainQueue"
                    + "\n\'D\' Delete Passenger from trainQueue\n\'S\' Store trainQueue data into a plain text file"
                    + "\n\'L\' Load data back from file into the trainQueue\n\'R\' Run the simulation and produce report\n"
                    + "Please enter one of the above options: ");
            
            Scanner in = new Scanner(System.in);
            
            char option = in.next().charAt(0);
                        
            switch(option){
                case 'A':
                    //Add Passenger to train Queue
                    System.out.println("------------------------------------------");
                    System.out.print("Please enter passenger first name: ");
                    String firstName = in.next();
                    System.out.print("Please enter passenger surname: ");
                    String surName = in.next();
                    System.out.print("Please enter seconds in Queue: ");
                    int sec = in.nextInt();
                    
                    Passenger passengerObj = new Passenger();
                    
                    passengerObj.setName(firstName, surName);
                    
                    passengerObj.setSecondsInQueue(sec);
                    
                    trainQueue.add(passengerObj);
                                        
                    break;
                    
                case 'V':
                    //View the queue
                    trainQueue.display();
                    break;
                
                case 'D':
                    // dequeue passenger
                    trainQueue.remove();
                    break;
                
                case 'S':
                    
                    //Check if queue empty
                    if(trainQueue.isEmpty()){
                        System.out.println("Queue is empty.");
                        return;
                    }
                    //Create plain text file
                     try{
                        queueData.createNewFile();
                     //Write into plain text file
                        FileWriter dataWriter = new FileWriter(fileName);
                        
                        dataWriter.write(trainQueue.getQueueString());
                        
                        dataWriter.close();
                        
                        System.out.println("Data stored in plain text file.");
                        
                    }catch(IOException e){
                        System.out.println("An error occurred.");
                        e.printStackTrace(); 
                    }
                    break;
                    
                case 'L':
                    
                    if(queueData.exists()){
                    
                    try{
                        Scanner fileReader = new Scanner(queueData);
                        while(fileReader.hasNextLine()){
                            
                            String line = fileReader.nextLine();
                            String [] dataArray = line.split(" ",-2);
                                                        
                            Passenger passenger = new Passenger();
                            passenger.setName(dataArray[0], dataArray[1]);
                            passenger.setSecondsInQueue(Integer.parseInt(dataArray[2]));
                            
                            trainQueue.add(passenger);
                            
                        }
                    }catch (FileNotFoundException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    }else{
                        
                        System.out.println("File is empty.");
                    }
                    
                    break;
                    
                case 'R':
                    
                    int maximumInQueue = 0;
                    int maximumWaitingInQueue = 0;
                    int minimumWaitingInQueue = 0;
                    int sumOfSeconds = 0;
                    int averageWaitingInQueue = 0;
                    
                    try{
                        
                        // read passengers file and put move all passenger int waiting room
                        Scanner passengerReader = new Scanner(passengerFile);
                        while(passengerReader.hasNext()){
                           
                            String line = passengerReader.nextLine();
                            String[] passengerName = line.split(" ",-2);                            
                            Passenger waitingPassenger = new Passenger();
                            waitingPassenger.setName(passengerName[0], passengerName[1]);
                            waitingRoom.add(waitingPassenger);
                        }
                        
                    }catch (FileNotFoundException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    
                    //loop until Queue is empty
                    do{
                                           
                        // use one die to get number of passenger will be moving to queue
                        int dieOne = diceRoller.nextInt(6) + 1;
                 
                        // moving passenger from waiting room to queue
                        while(dieOne != 0){
                            if(!waitingRoom.isEmpty()){
                               trainQueue.add(waitingRoom.get(0));
                               waitingRoom.remove(0);
                            }
                            else
                                break;
     
                            dieOne--;
                        }
                        // use three dice to get procesing delay number
                        int processingDelay = 0;
                        for(int k = 0; k < 3; k++){
                            
                        int dieTwo = diceRoller.nextInt(6) + 1;
                        processingDelay += dieTwo;
                        }
                        
                       trainQueue.addSecondsToQueue(processingDelay);
                       
                       //get maximum stayed in trainQueue
                       if(trainQueue.getMaxStay() > maximumInQueue)
                           maximumInQueue = trainQueue.getMaxStay();
                        
                       //dequeue passenger
                        Passenger donePassenger = trainQueue.remove();
                        //Gather data
                        reportList.add(donePassenger);
                        
                        
                    }while(!trainQueue.isEmpty());
                   
                    minimumWaitingInQueue = reportList.get(0).getSeconds();
                    maximumWaitingInQueue = reportList.get(0).getSeconds();
                    //get the maximum wait time 
                   for(int i = 0;i < reportList.size(); i++){
                       
                       if(reportList.get(i).getSeconds() > maximumWaitingInQueue){
                           maximumWaitingInQueue = reportList.get(i).getSeconds();
                       }
                       
                       if(reportList.get(i).getSeconds() < minimumWaitingInQueue ){
                           
                           minimumWaitingInQueue = reportList.get(i).getSeconds();
                       }
                       
                       sumOfSeconds+=reportList.get(i).getSeconds();
                   }
                   
                    //calculate the average time 
                    averageWaitingInQueue = sumOfSeconds / 30;
                   String reportOutput = "Maximum stayed in Queue: "+maximumInQueue+" Passengers\n"+
                    "Maximum waiting time: "+maximumWaitingInQueue+" S\n"+
                    "Minimum waiting time: "+ minimumWaitingInQueue+" S\n"+
                    "Average waiting time for all the passengers: "+averageWaitingInQueue+" S\n";
                    
                   System.out.println(reportOutput);
                    try{
                    reportFile.createNewFile();
                    FileWriter reportWriter = new FileWriter("report.dat");

                    for(Passenger passenger: reportList){
                       
                        String passengerName = passenger.getName();
                        int waitingTime = passenger.getSeconds();
                        
                        reportWriter.write("Name: "+passengerName+"\nSeconds: "+waitingTime+" S\n");
                        
                    }
                    reportWriter.write(reportOutput);
                    reportWriter.close();
                    }catch(IOException e){
                        System.out.println("An error occurred.");
                        e.printStackTrace(); 
                    }
                    
                    break;
                
                default:
                    
                    System.out.println("Please write letter of the above options");
                    
                    break;
                      
            }
        }
    }
    
  
     
}
