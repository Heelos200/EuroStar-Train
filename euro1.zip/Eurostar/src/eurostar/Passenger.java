package eurostar;

public class Passenger {
    // Passenger name
    private String firstName,surname;
    //How much passenger stayed in queue
    private int SecondsInَََََQueue;  
    //Getters & Setters
    public String getName(){return firstName+" "+surname;}
    
    public void setName(String name, String surname){
        firstName = name;
        this.surname = surname;
    }
    
    public int getSeconds(){ return SecondsInَََََQueue;}
    
    public void setSecondsInQueue(int sec){
        SecondsInَََََQueue = sec;
    }
    //Display passenger information
    public void display(){
        System.out.println("Name: "+firstName+" "+surname+"\nSeconds In Queue: "+SecondsInَََََQueue);
    }
    
   
    
}
